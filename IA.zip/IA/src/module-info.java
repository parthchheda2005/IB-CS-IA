module iA {
	requires java.desktop;
	requires sqlite.jdbc;
	requires java.sql;
	requires jfreechart;
	requires java.logging;
}